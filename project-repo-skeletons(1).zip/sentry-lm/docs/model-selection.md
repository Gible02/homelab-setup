# Model Selection

- [ ] Requirements: 16GB VRAM, CUDA, 12–14B quantized target
- [ ] Models evaluated + why
- [ ] Quantization tradeoffs (speed vs. quality)
- [ ] Final choice + benchmark notes
