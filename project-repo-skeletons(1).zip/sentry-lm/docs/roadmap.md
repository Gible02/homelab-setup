# Roadmap

- [ ] Phase 1 (done): triage.py + injection resistance
- [ ] Phase 2: TODO
- [ ] Phase 3: TODO
- [ ] Stretch goals
