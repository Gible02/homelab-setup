# VPN Remote Access (WireGuard)

- [ ] Server setup on desktop (UDP 51820, forwarded to pfSense WAN .50.2)
- [ ] 5 client device configs (peer setup process)
- [ ] Double-NAT issue with Optimum gateway + resolution
- [ ] Security posture: keys, allowed IPs, kill switch
