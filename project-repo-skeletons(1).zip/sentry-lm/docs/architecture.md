# Architecture

- [ ] High-level diagram (alert source → triage.py → Ollama → output)
- [ ] Host specs: desktop "burger", RTX 5060 Ti 16GB
- [ ] Network placement (192.168.50.x) and VPN access path
- [ ] Component descriptions: triage.py, Ollama runtime, model choice
