# Hardware Build Log

- [ ] GPU search process (16GB VRAM + CUDA requirement, Marketplace hunting)
- [ ] Final parts list (RTX 5060 Ti 16GB, motherboard, Lian Li O11 Dynamic XL)
- [ ] Case transplant + PSU short-circuit troubleshooting
- [ ] Fan configuration / thermals
