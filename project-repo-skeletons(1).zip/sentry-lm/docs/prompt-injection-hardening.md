# Prompt-Injection Hardening

- [ ] Threat model: malicious content inside alert payloads
- [ ] Mitigations implemented in triage.py
- [ ] Test cases / adversarial examples tried
- [ ] Known limitations
