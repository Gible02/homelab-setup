# SENTRY-LM — Self-Hosted LLM SOC Alert Triage System

> One-paragraph summary: what SENTRY-LM is, why local/self-hosted, what problem it solves (AI-assisted triage of SIEM/IDS alerts without cloud dependency).

<!-- TODO: architecture diagram image here (assets/architecture.png) -->

## Overview
- [ ] Problem statement (alert fatigue, manual triage)
- [ ] Solution summary (Ollama + 12–14B quantized models, local inference)
- [ ] Key design goals: privacy, offline capability, prompt-injection resistance

## Features
- [ ] triage.py — alert ingestion + Ollama integration
- [ ] Prompt-injection resistance measures
- [ ] Remote access via self-hosted WireGuard VPN (5 client devices)
- [ ] TODO: future phases

## Architecture
See [docs/architecture.md](docs/architecture.md)
- [ ] Host: desktop "burger"
- [ ] GPU: RTX 5060 Ti 16GB (CUDA)
- [ ] Model runtime: Ollama, 12–14B quantized models
- [ ] Data flow: SIEM/IDS alert → triage.py → LLM → verdict/summary

## Quick Start
- [ ] Prerequisites
- [ ] Install steps
- [ ] Usage example (sample alert in → triage output)

## Security Considerations
- [ ] Prompt-injection hardening approach → docs/prompt-injection-hardening.md
- [ ] VPN-only remote exposure, no public ports beyond WireGuard UDP 51820
- [ ] Double-NAT resolution notes (Optimum ISP gateway)

## Hardware Build
- [ ] Build log summary → docs/hardware-build.md (Lian Li O11 Dynamic XL, PSU troubleshooting, GPU selection process)

## Roadmap
- [ ] Phase 1 (complete): triage.py, injection resistance, README
- [ ] Phase 2: TODO (e.g., Wazuh alert pipeline integration)
- [ ] Phase 3: TODO

## Skills Demonstrated
- [ ] Local LLM deployment / GPU inference
- [ ] Python scripting
- [ ] VPN architecture (WireGuard)
- [ ] AI security (prompt-injection defense)
