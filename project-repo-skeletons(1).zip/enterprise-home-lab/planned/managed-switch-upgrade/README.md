# Managed Switch Upgrade (Planned)

- [ ] Requirements: small, quiet, fanless, 24/7 duty
- [ ] Candidates evaluated
- [ ] Migration plan off the TP-Link flat network
