# TrueNAS (Planned)

- [ ] Hardware plan
- [ ] Pool/dataset design
- [ ] Use cases (backups, lab storage)
