# Security Onion (Planned)

- [ ] Hardware target + sizing
- [ ] Deployment plan
- [ ] Goals (NSM visibility, Zeek/Suricata comparison)
