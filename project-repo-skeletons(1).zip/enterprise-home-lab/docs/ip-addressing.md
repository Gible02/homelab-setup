# IP Addressing & VLAN Plan

- [ ] .50 network (ASUS / wifi / ASA outside)
- [ ] .60 network (pfSense LAN / workstation / Proxmox)
- [ ] .10 network (ASA inside lab)
- [ ] DHCP scopes, static assignments, reserved ranges
