# Network Evolution

- [ ] Original topology: Internet → RT-AX82U → ASA outside (.50.100) → ASA inside (192.168.10.1) → 2960 → PC (.10.10)
- [ ] Why Layout B: pfSense as wired gatekeeper, wifi bypass rationale
- [ ] Lessons learned per iteration
