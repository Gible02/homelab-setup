# Suricata Network IDS

- [ ] Install + interface config on Orange Pi 5
- [ ] Rule sources / tuning
- [ ] Wazuh integration (eve.json ingestion)
- [ ] Sample detections
