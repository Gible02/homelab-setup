# Red/Blue Team VirtualBox Lab

- [ ] Segmented topology (Kali attacker, Win11 victim, Wazuh OVA)
- [ ] Network design on the Zenbook
- [ ] Attack/detect exercises run
