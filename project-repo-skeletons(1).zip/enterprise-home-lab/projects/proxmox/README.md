# Proxmox Single-Node Conversion

- [ ] Win10 box → Proxmox VE install (.60.11, 16GB)
- [ ] Storage/network setup, VirtIO
- [ ] VMs hosted (links to helpdesk-lab repo)
