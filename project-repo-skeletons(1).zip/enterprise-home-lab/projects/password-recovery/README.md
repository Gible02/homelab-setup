# Physical Password Recovery

- [ ] ASA 5515-X procedure
- [ ] Catalyst 2960 procedure
- [ ] ISR 1921 procedure
- [ ] Lessons learned
