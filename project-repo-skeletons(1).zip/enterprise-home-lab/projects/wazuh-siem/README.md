# Wazuh SIEM (Orange Pi 5)

- [ ] Deployment steps
- [ ] Windows endpoint agent enrollment
- [ ] Dashboards / rules configured
- [ ] Integration with Suricata
