# Orange Pi 5 Lab Server

- [ ] Ubuntu Server install process
- [ ] Boot failure troubleshooting (image variant / flash issues)
- [ ] Final working setup + services hosted
