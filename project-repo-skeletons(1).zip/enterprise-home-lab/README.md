# Enterprise Home Lab — Network Security Infrastructure

> One-paragraph summary: self-funded enterprise-grade lab (~$1,200 invested, $5,800+ equipment value) for hands-on networking + security engineering. Cisco routing/switching, firewalling, IDS/SIEM, virtualization, and segmentation.

<!-- TODO: topology diagram at top (diagrams/layout-b.png) -->

## Current Topology — "Layout B"
- [ ] Diagram + walkthrough: Optimum ISP → ASUS RT-AX82U (.50, wifi clients bypass filtering) → pfSense wired gatekeeper (WAN .50.2 / LAN 192.168.60.1) → TP-Link 8-port switch (.60) → Win11 workstation (.60.10) + Proxmox node (.60.11)
- [ ] Lab chain double-gated behind pfSense: 1921 → ASA → 2960
- [ ] WireGuard port forward (UDP 51820 → .50.2)

## Hardware Inventory
- [ ] Cisco ASA 5515-X
- [ ] Catalyst 2960
- [ ] 2x Catalyst 3750 PoE-48
- [ ] Cisco 891F + 1921 ISR routers
- [ ] ASUS RT-AX82U (192.168.50.1)
- [ ] Dell box — pfSense
- [ ] Win10 box → single-node Proxmox (.60.11, 16GB)
- [ ] Orange Pi 5 (Wazuh SIEM)
- [ ] Synology NAS, APC Smart-UPS 1000, Axis M3006-V IP camera
- [ ] TP-Link 8-port switch (to be replaced — see planned/)

## Configurations
| Device | Highlights | Docs |
|---|---|---|
| ASA 5515-X | Single mode from scratch: inside G0/0 192.168.10.1/24, outside G0/1 192.168.50.100/24, NAT/PAT, inside-out ACL, default route, verified stateful inspection | configs/asa/ |
| Catalyst 2960 | TODO | configs/catalyst-2960/ |
| Catalyst 3750s | TODO | configs/catalyst-3750/ |
| ISR 1921 / 891F | TODO | configs/isr-1921/, configs/isr-891f/ |
| pfSense | Wired gatekeeper, WAN/LAN, port forwards | configs/pfsense/ |
| GNS3 | IOS router template w/ real IOS image, SSH via loopback adapter + Cloud node | configs/gns3/ |

## Projects
- [ ] Wazuh SIEM on Orange Pi 5 (+ Windows endpoint agents) → projects/wazuh-siem/
- [ ] Suricata IDS integrated with Wazuh → projects/suricata-ids/
- [ ] Orange Pi 5 Ubuntu Server build + boot troubleshooting → projects/orange-pi-5/
- [ ] Proxmox single-node conversion → projects/proxmox/
- [ ] Physical password recovery: ASA, 2960, 1921 → projects/password-recovery/
- [ ] Red/blue team VirtualBox lab (Kali, Win11 victim, Wazuh OVA, segmented) → projects/red-blue-lab/

## Planned / In Progress
- [ ] Security Onion deployment → planned/security-onion/
- [ ] TrueNAS build → planned/truenas/
- [ ] Fanless managed switch to replace TP-Link → planned/managed-switch-upgrade/

## Skills Demonstrated
- [ ] Cisco IOS/ASA configuration (NAT, ACLs, routing)
- [ ] Network segmentation & firewall design (pfSense, ASA)
- [ ] IDS/SIEM deployment (Suricata, Wazuh)
- [ ] Virtualization (Proxmox, VirtualBox, GNS3)
- [ ] Physical device recovery procedures
