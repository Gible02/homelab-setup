# Device Configuration

- [ ] Sanitized running-config (strip secrets/keys before committing)
- [ ] Config walkthrough / rationale
- [ ] Verification output (show commands, tests)
