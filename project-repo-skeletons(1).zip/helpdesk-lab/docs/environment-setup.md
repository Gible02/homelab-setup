# Environment Setup

- [ ] Proxmox VM allocation plan (DC 4GB / client 4GB / overhead)
- [ ] Windows Server install + static IP
- [ ] AD DS promotion, DNS config, lab domain naming
- [ ] DHCP decision (DC vs pfSense)
- [ ] OU / group / user structure
- [ ] GPOs configured
- [ ] Client domain join steps
