# Help Desk Simulation Lab — Active Directory & IT Support Environment

> One-paragraph summary: simulated enterprise support environment (Windows Server AD domain on Proxmox) with a documented portfolio of resolved support tickets.

<!-- TODO: topology diagram (docs/topology.png) -->

## Environment
- [ ] Hypervisor: Proxmox VE single node (192.168.60.11, 16GB)
- [ ] DC: Windows Server (AD DS, DNS, DHCP?) — VM specs
- [ ] Clients: Win11 (domain-joined), optional second client
- [ ] Domain name, OU structure, GPOs applied
- [ ] Shared drives / printers / permission structure

## Ticket Index
| # | Ticket | Category | Status |
|---|---|---|---|
| 001 | TODO | Account | ☐ |
| 002 | TODO | Permissions | ☐ |
| 003 | TODO | Network | ☐ |
<!-- add rows as tickets are completed -->

## Categories Covered
- [ ] Account management (lockouts, resets, onboarding/offboarding)
- [ ] NTFS/share permission conflicts
- [ ] Printer + network connectivity
- [ ] GPO troubleshooting
- [ ] DNS/DHCP client issues

## Skills Demonstrated
- [ ] Active Directory administration
- [ ] Windows Server + Group Policy
- [ ] Structured troubleshooting & documentation
- [ ] Virtualization (Proxmox)
