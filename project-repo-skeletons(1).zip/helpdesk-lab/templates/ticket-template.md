# TICKET-XXX — <Short Title>

**Category:**
**Priority:**
**Reported by:** (simulated user)
**Date:**

## Issue Reported
<!-- user-facing description of the problem -->

## Environment
<!-- affected machine(s), user(s), relevant config -->

## Troubleshooting Steps
1.
2.
3.

## Root Cause

## Resolution

## Prevention / Notes
